class NestipyGraphqlKey:
    resolver: str = '__graphql_resolver__'
    query: str = '__graphql_query__'
    mutation: str = '__graphql_mutation__'
    subscription: str = '__graphql_subscription__'
    handler: str = '__graphql_handler__'
    return_type: str = '__graphql_return_type__'
