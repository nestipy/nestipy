class TemplateKey:
    MetaRender: str = "__template__render__"
    MetaEngine: str = "__template__engine__"
