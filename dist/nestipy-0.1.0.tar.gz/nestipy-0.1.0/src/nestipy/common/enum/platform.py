from enum import Enum


class PlatFormType(Enum):
    LITESTAR = "LITESTAR"
    FASTAPI = "FASTAPI"
