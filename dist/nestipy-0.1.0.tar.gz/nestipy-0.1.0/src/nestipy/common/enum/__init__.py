from .platform import PlatFormType

__all__ = [
    'PlatFormType'
]
