class NestipyFastApiApplication:
    pass


class NestipyBlackSheepApplication:
    pass
